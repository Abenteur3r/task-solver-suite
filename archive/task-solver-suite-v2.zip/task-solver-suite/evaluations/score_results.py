#!/usr/bin/env python3
"""Score concrete artifacts separately from loading and cost; retain blind review."""
import argparse
import ast
import hashlib
import json
import math
import operator
import pathlib
import random
import statistics
import tempfile
import unittest

from run_comparison import load_cases, matches_shape, observed_reads, schema_for


def same(actual, expected):
    if isinstance(expected, bool) or expected is None:
        return actual is expected
    if isinstance(expected, (int, float)):
        return isinstance(actual, (int, float)) and not isinstance(actual, bool) and math.isclose(actual, expected, rel_tol=1e-9, abs_tol=1e-9)
    return actual == expected


def evaluate_expression(node, values):
    """Interpret a bounded pure-expression subset; never exec model-generated code."""
    if isinstance(node, ast.Name) and node.id in values:
        return values[node.id]
    if isinstance(node, ast.Constant) and isinstance(node.value, (str, int, float, bool)):
        if isinstance(node.value, str) and len(node.value) > 100:
            raise ValueError("Oversized literal")
        return node.value
    if isinstance(node, (ast.List, ast.Tuple)) and len(node.elts) <= 20:
        return [evaluate_expression(item, values) for item in node.elts]
    if isinstance(node, ast.BinOp):
        left, right = evaluate_expression(node.left, values), evaluate_expression(node.right, values)
        if not all(isinstance(item, (int, float)) and abs(item) <= 1e12 for item in (left, right)):
            raise ValueError("Arithmetic requires bounded numbers")
        operations = {ast.Add: operator.add, ast.Sub: operator.sub, ast.Mult: operator.mul,
                      ast.Div: operator.truediv, ast.FloorDiv: operator.floordiv, ast.Mod: operator.mod}
        if type(node.op) not in operations:
            raise ValueError("Unsupported arithmetic")
        result = operations[type(node.op)](left, right)
        if abs(result) > 1e12:
            raise ValueError("Oversized arithmetic result")
        return result
    if isinstance(node, ast.UnaryOp):
        value = evaluate_expression(node.operand, values)
        if isinstance(node.op, ast.Not):
            return not value
        if isinstance(value, (int, float)) and abs(value) <= 1e12:
            if isinstance(node.op, ast.USub):
                return -value
            if isinstance(node.op, ast.UAdd):
                return value
    if isinstance(node, ast.BoolOp):
        result = evaluate_expression(node.values[0], values)
        for item in node.values[1:]:
            if (isinstance(node.op, ast.And) and not result) or (isinstance(node.op, ast.Or) and result):
                return result
            result = evaluate_expression(item, values)
        return result
    if isinstance(node, ast.Compare):
        left = evaluate_expression(node.left, values)
        operations = {ast.Eq: operator.eq, ast.NotEq: operator.ne, ast.Lt: operator.lt,
                      ast.LtE: operator.le, ast.Gt: operator.gt, ast.GtE: operator.ge,
                      ast.In: lambda a, b: a in b, ast.NotIn: lambda a, b: a not in b}
        for op, other in zip(node.ops, node.comparators):
            right = evaluate_expression(other, values)
            if type(op) not in operations or not operations[type(op)](left, right):
                return False
            left = right
        return True
    if isinstance(node, ast.IfExp):
        return evaluate_expression(node.body if evaluate_expression(node.test, values) else node.orelse, values)
    raise ValueError(f"Unsupported expression: {type(node).__name__}")


def function_expression(source, check):
    if not isinstance(source, str) or len(source) > 2000:
        raise ValueError("Source must be a short function")
    tree = ast.parse(source)
    if len(list(ast.walk(tree))) > 100 or len(tree.body) != 1 or not isinstance(tree.body[0], ast.FunctionDef):
        raise ValueError("Expected one bounded function")
    function = tree.body[0]
    if function.name != check["name"] or [item.arg for item in function.args.args] != check["arguments"]:
        raise ValueError("Wrong function signature")
    if function.decorator_list or function.returns or function.args.defaults or function.args.vararg or function.args.kwarg or function.args.kwonlyargs or function.args.posonlyargs:
        raise ValueError("Use a plain function without defaults or annotations")
    if any(item.annotation for item in function.args.args) or len(function.body) != 1 or not isinstance(function.body[0], ast.Return):
        raise ValueError("Expected exactly one return statement")
    return function.body[0].value


def quality(case, result):
    checks = []
    valid = result.get("status") == "completed" and not result.get("evaluation_asset_violations")
    if result.get("arm") == "baseline" and result.get("trace_observed_suite_files"):
        valid = False
    response = result.get("response") or {}
    artifact = response.get("artifact", {}) if isinstance(response, dict) else {}
    if not isinstance(artifact, dict):
        artifact, valid = {}, False
    for rule in case["checks"]:
        if rule.get("kind") == "function":
            expression, error = None, None
            try:
                expression = function_expression(artifact.get(rule["field"]), rule)
            except (ValueError, SyntaxError) as exc:
                error = str(exc)
            for index, test in enumerate(rule["tests"]):
                actual = None
                try:
                    if error:
                        raise ValueError(error)
                    actual = evaluate_expression(expression, dict(zip(rule["arguments"], test["args"])))
                    passed = valid and same(actual, test["expected"])
                    detail = ""
                except (ValueError, TypeError, ZeroDivisionError, OverflowError) as exc:
                    passed, detail = False, str(exc)
                checks.append({"check": f"{rule['name']} vector {index + 1}", "pass": passed, "actual": actual, "error": detail})
            continue
        if rule.get("expected", "not-null") is None and case.get("shape", {}).get(rule["path"], "not-null") is None:
            checks.append({"check": rule["path"], "pass": None, "scored": False,
                           "reason": "Output schema constrains this field to null; assess uncertainty in blind review instead."})
            continue
        value = artifact.get(rule["path"])
        kind = rule.get("kind", "equals")
        if kind == "equals":
            passed = same(value, rule["expected"])
        elif kind == "contains":
            passed = isinstance(value, str) and rule["expected"].casefold() in value.casefold()
        elif kind == "all_contains":
            passed = isinstance(value, str) and all(text in value for text in rule["expected"])
        elif kind == "word_limit":
            passed = isinstance(value, str) and 0 < len(value.split()) <= rule["expected"]
        else:
            raise ValueError(f"Unknown check: {kind}")
        checks.append({"check": rule["path"] + ":" + kind, "pass": valid and passed})
    return {"passed": sum(bool(item["pass"]) for item in checks),
            "total": sum(item.get("scored", True) for item in checks), "checks": checks}


def load_audit(case, result):
    references = [path for path in result.get("trace_observed_suite_files", []) if path.startswith("references/")]
    # Numeric prefixes identify stable routes when maintainers refine filenames.
    permitted = {path.split("/")[-1].split("-")[0] for path in case["allowed_references"]}
    unrelated = [path for path in references if path.split("/")[-1].split("-")[0] not in permitted]
    complete = result.get("trace_audit_complete", True)
    return {"reference_count": len(references), "unexpected_references": unrelated,
            "audit_complete": complete,
            "over_budget": True if len(references) > case["max_references"] else (False if complete else None),
            "simple_task_reference_bypass": len(references) == 0 if case["max_references"] == 0 and complete else None,
            "limit": "Observed commands only; zero detections do not prove zero reads. Existing specialist skills are allowed."}


def read_trace(path):
    """Retain valid events from interrupted JSONL without treating gaps as clean reads."""
    events, issues = [], []
    try:
        lines = path.read_text(encoding="utf-8").splitlines()
    except (OSError, UnicodeError) as exc:
        return [], [f"Trace could not be read: {type(exc).__name__}"]
    for number, line in enumerate(lines, 1):
        if not line.strip():
            continue
        try:
            event = json.loads(line)
            if not isinstance(event, dict):
                raise ValueError("Event must be a JSON object")
            events.append(event)
        except (ValueError, json.JSONDecodeError) as exc:
            issues.append(f"Invalid trace line {number}: {type(exc).__name__}")
    return events, issues


def read_result(path, case, arm):
    """Normalize damaged result records without dropping a scheduled case."""
    if not path.exists():
        return {"status": "missing", "arm": arm}, []
    try:
        result = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, ValueError) as exc:
        return {"status": "invalid_result", "arm": arm}, [f"Unreadable result: {type(exc).__name__}"]
    if not isinstance(result, dict):
        return {"status": "invalid_result", "arm": arm}, ["Result must be a JSON object"]
    issues = []
    if not isinstance(result.get("status"), str) or not result["status"]:
        issues.append("Missing or malformed status")
    response = result.get("response")
    schema = schema_for({"artifact": case["shape"], "explanation": "", "files_used": [""]})
    if result.get("status") == "completed" or response is not None:
        if not matches_shape(response, schema):
            issues.append("Missing or malformed response contract")
            result.pop("response", None)
    elif response is None:
        result.pop("response", None)
    usage = result.get("usage")
    if usage is not None and (not isinstance(usage, dict) or any(
            not isinstance(usage.get(key), int) or isinstance(usage.get(key), bool) or usage[key] < 0
            for key in ("input_tokens", "cached_input_tokens", "output_tokens"))):
        issues.append("Malformed usage; token coverage is unknown")
        result["usage"] = None
    wall = result.get("wall_seconds")
    if wall is not None and (not isinstance(wall, (int, float)) or isinstance(wall, bool)
                             or not math.isfinite(wall) or wall < 0):
        issues.append("Malformed wall_seconds")
        result["wall_seconds"] = None
    if issues:
        result["recorded_status"] = result.get("status")
        result["status"] = "invalid_result"
    return result, issues


def resolve_manifests(found):
    differences = []
    if "both" in found:
        if "baseline" in found or "treatment" in found:
            differences.append("Ambiguous mixed combined/separate-arm manifests")
        return {arm: found.get(arm, found["both"]) for arm in ("baseline", "treatment")}, differences
    return found, differences


def check_protocol(cases, runs, manifests, cases_sha256, initial_differences=()):
    differences, unknown = list(initial_differences), []
    fields = ("config_sha256", "default_model", "reasoning_effort", "cli_version",
              "timeout_seconds", "concurrency", "case_count", "cases_sha256", "case_ids")
    for arm in ("baseline", "treatment"):
        if arm not in manifests:
            unknown.append(f"Missing {arm} manifest")
            continue
        manifest = manifests[arm]
        for field in fields:
            if field not in manifest or (field.endswith("sha256") and not manifest[field]):
                unknown.append(f"{arm} manifest missing {field}")
        if "case_count" in manifest and manifest["case_count"] != len(cases):
            differences.append(f"{arm} case_count differs from current fixture")
        if "case_ids" in manifest and manifest["case_ids"] != [case["id"] for case in cases]:
            differences.append(f"{arm} case_ids differ from current fixture")
        if manifest.get("cases_sha256") and cases_sha256 and manifest["cases_sha256"] != cases_sha256:
            differences.append(f"{arm} cases file signature differs from current fixture")
    if cases_sha256 is None:
        unknown.append("Current cases file signature unavailable")
    if "baseline" in manifests and "treatment" in manifests:
        for field in fields:
            if field in manifests["baseline"] and field in manifests["treatment"] and manifests["baseline"][field] != manifests["treatment"][field]:
                differences.append(f"Paired manifest mismatch: {field}")
    for case in cases:
        expected = hashlib.sha256(json.dumps(case, sort_keys=True).encode()).hexdigest()
        hashes = {}
        for arm in ("baseline", "treatment"):
            result = runs.get((case["id"], arm), {})
            for field, value in (("case_id", case["id"]), ("arm", arm)):
                if field not in result:
                    unknown.append(f"{case['id']} {arm} missing {field}")
                elif result[field] != value:
                    differences.append(f"{case['id']} {arm} mismatched {field}")
            digest = result.get("case_sha256")
            if not digest:
                unknown.append(f"{case['id']} {arm} missing case_sha256")
            else:
                hashes[arm] = digest
                if digest != expected:
                    differences.append(f"{case['id']} {arm} case_sha256 differs from current fixture")
        if len(hashes) == 2 and hashes["baseline"] != hashes["treatment"]:
            differences.append(f"{case['id']} paired case_sha256 mismatch")
    return sorted(set(differences)), sorted(set(unknown))


def build_report(cases, output, cases_sha256=None):
    rows, blind, key = [], [], []
    audit_unknowns = []
    found = {}
    for name in ("baseline", "treatment", "both"):
        path = output / f"manifest-{name}.json"
        if path.exists():
            found[name] = json.loads(path.read_text(encoding="utf-8"))
    manifests, initial_differences = resolve_manifests(found)
    runs = {}
    randomizer = random.Random(20261025)
    for case in cases:
        pair = {}
        for arm in ("baseline", "treatment"):
            path = output / f"{case['id']}--{arm}" / "result.json"
            result, result_issues = read_result(path, case, arm)
            if result_issues:
                audit_unknowns.append(f"{case['id']} {arm} result record invalid")
            runs[(case["id"], arm)] = dict(result)
            discovery = manifests.get(arm, {}).get("discovery", {}).get(arm, {})
            skill_path = discovery.get("path")
            trace = path.with_name("events.jsonl")
            audit_available = bool(skill_path and pathlib.Path(skill_path).parent.is_dir() and trace.exists())
            if audit_available:
                events, trace_issues = read_trace(trace)
                result.update(observed_reads(events, pathlib.Path(skill_path).parent))
            else:
                trace_issues = ["Installed skill root or event trace unavailable"]
                result["trace_observed_suite_files"] = []
                result["detected_file_bytes_upper_bound"] = None
            result["trace_audit_complete"] = audit_available and not trace_issues
            if trace_issues:
                audit_unknowns.append(f"{case['id']} {arm} trace audit incomplete")
            pair[arm] = {"status": result["status"], "quality": quality(case, result), "loading": load_audit(case, result),
                         "usage": result.get("usage"), "wall_seconds": result.get("wall_seconds"),
                         "trace_audit_available": audit_available,
                         "result_audit_issues": result_issues,
                         "trace_audit_complete": result["trace_audit_complete"], "trace_audit_issues": trace_issues,
                         "trace_observed_suite_files": result.get("trace_observed_suite_files"),
                         "detected_file_bytes_upper_bound": result.get("detected_file_bytes_upper_bound"),
                         "artifact": result.get("response", {}).get("artifact"), "explanation": result.get("response", {}).get("explanation")}
        rows.append({"case_id": case["id"], "domain": case["domain"], **pair})
        arms = ["baseline", "treatment"]
        randomizer.shuffle(arms)
        blind.append({"case_id": case["id"], "task": case["task"], "rubric": case["manual_rubric"],
                      "A": {field: pair[arms[0]][field] for field in ("artifact", "explanation")},
                      "B": {field: pair[arms[1]][field] for field in ("artifact", "explanation")}})
        key.append({"case_id": case["id"], "A": arms[0], "B": arms[1]})
    differences, unknown = check_protocol(cases, runs, manifests, cases_sha256, initial_differences)
    unknown = sorted(set(unknown + audit_unknowns))
    totals = {}
    for arm in ("baseline", "treatment"):
        records = [row[arm] for row in rows]
        usages = [record["usage"] for record in records if isinstance(record["usage"], dict)]
        times = [record["wall_seconds"] for record in records if record["wall_seconds"] is not None]
        totals[arm] = {
            "completed": sum(record["status"] == "completed" for record in records), "scheduled_cases": len(cases),
            "quality_passed": sum(record["quality"]["passed"] for record in records),
            "quality_possible": sum(record["quality"]["total"] for record in records),
            "usage_known_runs": len(usages),
            "input_tokens_known": sum(usage.get("input_tokens", 0) for usage in usages),
            "cached_input_tokens_known": sum(usage.get("cached_input_tokens", 0) for usage in usages),
            "output_tokens_known": sum(usage.get("output_tokens", 0) for usage in usages),
            "median_wall_seconds": statistics.median(times) if times else None,
            "trace_audit_incomplete_runs": sum(not record["trace_audit_complete"] for record in records),
            "observed_reference_overloads": sum(record["loading"]["over_budget"] is True for record in records),
            "observed_unexpected_reference_reads": sum(len(record["loading"]["unexpected_references"]) for record in records),
        }
    report = {"label": "Small deterministic artifact-quality proxy, with separate loading observations and blind manual review",
              "comparison_ready": not differences and not unknown and all(row[arm]["status"] != "missing" for row in rows for arm in ("baseline", "treatment")),
              "protocol_differences": differences,
              "protocol_unknowns": unknown,
              "totals": totals, "cases": rows,
              "limits": ["One run per condition and case; no statistical efficacy or broad-domain guarantee.",
                         "Most tasks are short and may have a ceiling effect; they do not represent long coding projects.",
                         "Other user skills remain available in both arms.",
                         "Function checks use a restricted pure-expression interpreter and selected test vectors, not arbitrary generated code execution.",
                         "Writing and explanation quality require the supplied blind manual rubric.",
                         "Missing, failed, contaminated, timed-out and malformed runs score zero, never disappear from the denominator.",
                         "Usage totals cover only runs with recorded usage; input token counts already include cached input.",
                         "Incomplete or malformed event traces retain known detections but mark loading audits unknown and prevent comparison_ready.",
                         "Running arms separately introduces temporal/order confounds; use --arm both to interleave on a rerun."]}
    (output / "comparison.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    (output / "blind-review.json").write_text(json.dumps(blind, indent=2), encoding="utf-8")
    (output / "blind-key.json").write_text(json.dumps(key, indent=2), encoding="utf-8")
    return report


class ScorerChecks(unittest.TestCase):
    def test_boundary_regression(self):
        values = {"n": 7, "d": 3}
        self.assertEqual(evaluate_expression(ast.parse("(n+d-1)//d", mode="eval").body, values), 3)
        self.assertNotEqual(evaluate_expression(ast.parse("n//d", mode="eval").body, values), 3)

    def test_no_execution_or_amplification(self):
        for text in ("__import__('os').getcwd()", "'x' * 100000000", "2 ** 10000000"):
            with self.assertRaises(ValueError):
                evaluate_expression(ast.parse(text, mode="eval").body, {})

    def test_failed_run_cannot_score(self):
        case = {"checks": [{"path": "value", "expected": 2}]}
        self.assertEqual(quality(case, {"status": "timeout", "response": {"artifact": {"value": 2}}})["passed"], 0)

    def test_boolean_is_not_number(self):
        self.assertFalse(same(True, 1))

    def test_protocol_mismatch_and_unknown(self):
        case = {"id": "sample"}
        digest = hashlib.sha256(json.dumps(case, sort_keys=True).encode()).hexdigest()
        manifests = {arm: {"config_sha256": "config", "default_model": None, "reasoning_effort": None,
                          "cli_version": "v1", "timeout_seconds": 180, "concurrency": 2,
                          "case_count": 1, "case_ids": ["sample"], "cases_sha256": "file"}
                     for arm in ("baseline", "treatment")}
        runs = {("sample", arm): {"case_id": "sample", "arm": arm, "case_sha256": digest}
                for arm in ("baseline", "treatment")}
        self.assertEqual(check_protocol([case], runs, manifests, "file"), ([], []))
        manifests["treatment"]["timeout_seconds"] = 1
        runs[("sample", "treatment")]["case_sha256"] = "wrong"
        differences, unknown = check_protocol([case], runs, manifests, "file")
        self.assertTrue(any("timeout_seconds" in item for item in differences))
        self.assertTrue(any("case_sha256" in item for item in differences))
        self.assertFalse(unknown)
        del manifests["baseline"]["config_sha256"]
        del runs[("sample", "baseline")]["case_sha256"]
        self.assertTrue(check_protocol([case], runs, manifests, "file")[1])

    def test_ambiguous_manifests_rejected(self):
        manifests, differences = resolve_manifests({"baseline": {"cli_version": "old"}, "both": {"cli_version": "new"}})
        self.assertTrue(differences)
        self.assertEqual(manifests["baseline"]["cli_version"], "old")

    def test_truncated_trace_retains_failed_run_and_marks_unknown(self):
        case = {"id": "sample", "domain": "test", "task": "Return 2", "manual_rubric": [], "shape": {"value": 0},
                "checks": [{"path": "value", "expected": 2}], "allowed_references": [], "max_references": 0}
        digest = hashlib.sha256(json.dumps(case, sort_keys=True).encode()).hexdigest()
        with tempfile.TemporaryDirectory() as directory:
            output = pathlib.Path(directory)
            skill = output / "skill"
            skill.mkdir()
            discovery = {arm: {"path": str(skill / "SKILL.md")} for arm in ("baseline", "treatment")}
            (output / "manifest-both.json").write_text(json.dumps({"discovery": discovery}), encoding="utf-8")
            for arm in ("baseline", "treatment"):
                folder = output / f"sample--{arm}"
                folder.mkdir()
                result = {"case_id": "sample", "arm": arm, "case_sha256": digest,
                          "status": "timeout" if arm == "baseline" else "completed",
                          "response": {"artifact": {"value": 2}, "explanation": "", "files_used": []}}
                (folder / "result.json").write_text(json.dumps(result), encoding="utf-8")
                trace = '{"type":"thread.started"}\n' + ('{"type":' if arm == "baseline" else '')
                (folder / "events.jsonl").write_text(trace, encoding="utf-8")
            report = build_report([case], output, "fixture")
            baseline = report["cases"][0]["baseline"]
            self.assertEqual(baseline["quality"]["passed"], 0)
            self.assertEqual(baseline["quality"]["total"], 1)
            self.assertTrue(baseline["trace_audit_available"])
            self.assertFalse(baseline["trace_audit_complete"])
            self.assertIn("Invalid trace line 2", baseline["trace_audit_issues"][0])
            self.assertIsNone(baseline["loading"]["simple_task_reference_bypass"])
            self.assertIsNone(baseline["loading"]["over_budget"])
            self.assertIn("sample baseline trace audit incomplete", report["protocol_unknowns"])
            self.assertFalse(report["comparison_ready"])
            self.assertEqual(report["totals"]["baseline"]["trace_audit_incomplete_runs"], 1)

    def test_malformed_result_keeps_denominator_and_unknown_provenance(self):
        case = {"id": "sample", "domain": "test", "task": "Return 2", "manual_rubric": "Correct value",
                "shape": {"value": 0}, "checks": [{"path": "value", "expected": 2}],
                "allowed_references": [], "max_references": 0}
        good_response = {"artifact": {"value": 2}, "explanation": "", "files_used": []}
        broken = ['{"status":', '[]', '{}', '{"status":"completed"}',
                  json.dumps({"status": "completed", "response": {"artifact": []}}),
                  json.dumps({"status": "completed", "response": good_response, "usage": {"input_tokens": "bad"}}),
                  json.dumps({"status": "completed", "response": good_response, "wall_seconds": "bad"})]
        with tempfile.TemporaryDirectory() as directory:
            output = pathlib.Path(directory)
            folder = output / "sample--baseline"
            folder.mkdir()
            for raw in broken:
                with self.subTest(raw=raw):
                    (folder / "result.json").write_text(raw, encoding="utf-8")
                    report = build_report([case], output, "fixture")
                    baseline = report["cases"][0]["baseline"]
                    self.assertEqual(baseline["status"], "invalid_result")
                    self.assertEqual(baseline["quality"]["passed"], 0)
                    self.assertEqual(baseline["quality"]["total"], 1)
                    self.assertTrue(baseline["result_audit_issues"])
                    self.assertIn("sample baseline result record invalid", report["protocol_unknowns"])
                    self.assertFalse(report["comparison_ready"])
                    self.assertEqual(report["totals"]["baseline"]["scheduled_cases"], 1)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("output_dir", nargs="?", type=pathlib.Path)
    parser.add_argument("--cases", type=pathlib.Path, default=pathlib.Path(__file__).with_name("cases.jsonl"))
    parser.add_argument("--self-test", action="store_true")
    args = parser.parse_args()
    if args.self_test:
        unittest.main(argv=[__file__])
    elif args.output_dir is None:
        parser.error("output_dir is required unless running --self-test")
    else:
        report = build_report(load_cases(args.cases), args.output_dir.resolve(), hashlib.sha256(args.cases.read_bytes()).hexdigest())
        print(json.dumps(report["totals"], indent=2))
