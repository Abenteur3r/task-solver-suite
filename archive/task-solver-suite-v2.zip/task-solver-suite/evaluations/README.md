# Paired artifact evaluation

This small benchmark measures concrete task outputs separately from reference loading, token use, and elapsed time. It is a reproducible diagnostic for this suite, not evidence that a skill improves every task or model.

## Design

The 12 cases in [cases.jsonl](cases.jsonl) cover software, debugging, data, ML, RAG, product planning, research, decisions, operations, security, writing, and quantitative work. Facts and fixtures are included in each prompt. No live data, service calls, deployments, or submissions are needed. The model returns a JSON task artifact and explanation. No model-created application or document file is claimed.

Every case runs in two fresh ephemeral Codex sessions:

- **Baseline:** the personal `task-solver-suite` entry is disabled through a command-line `skills.config` override.
- **Treatment:** that entry is enabled and the prompt explicitly mentions `$task-solver-suite`.

Other configured skills remain available in both conditions. The runner preserves their existing configuration entries and does not write user configuration. Both conditions use the same CLI defaults, read-only sandbox, no approval escalation, prompt facts, and output schema. No model or reasoning override is supplied. The manifest records configured model/effort when present; `null` means the CLI default was not explicitly set, not that the resolved server model was independently verified.

The runner first uses app-server `skills/list` to verify the installed path, personal `user` scope, and expected enabled state without adding discovery roots. It refuses to continue if this check fails. Each model run is capped at 180 seconds, output logs are bounded, and concurrency is at most two. Commands run without a shell wrapper. Before writing a manifest, the runner checks every planned run directory and rejects conflicting combined/separate-arm modes. Result files are never silently replaced.

## Run

Python 3.11+ and an authenticated Codex CLI are development prerequisites. The skill itself remains independent of these tools. Running the benchmark invokes the model and consumes account usage; run it only when the user has authorized that evaluation.

From the repository root, choose an output directory outside the skill package:

```text
python evaluations/run_comparison.py --cli /absolute/path/to/codex --skill /absolute/path/to/installed/task-solver-suite/SKILL.md --output-dir /absolute/path/to/results --arm both
python evaluations/score_results.py /absolute/path/to/results
```

The same commands accept Windows absolute paths; quote paths containing spaces. To inspect discovery without invoking a model, add `--probe-only`. To collect the baseline before installing a revised suite, use `--arm baseline`, then run `--arm treatment` against the same output directory after installation. Only the installed skill files should change. Keep case prompts, output schemas, CLI, other skills, and default model settings constant. Separate-arm execution creates a time/order confound; `--arm both` interleaves conditions in a fixed shuffled order for reruns.

Do not copy benchmark answers or logs into a task's work directory. The prompt forbids reading evaluation assets, and the harness flags evaluation filenames seen in executed commands. This detection is incomplete; inspect traces before accepting surprising results. Installed evaluation assets are not secret or access-controlled, so this is a contamination precaution rather than a secure benchmark boundary.

## Evidence and scoring

The separate [routing_cases.jsonl](routing_cases.jsonl) contains six more complex Russian-language requests. They exercise domain selection, resumption of deep contradiction analysis, and avoiding ML work in a pitch-only request. Run them with `--cases evaluations/routing_cases.jsonl --arm treatment` and a fresh output directory. These are routing smoke tests with manually reviewed artifacts, not a second paired quality benchmark. Their empty automatic-check lists must not be presented as quality passes. Inspect successful read traces, specialist delegation, output scope, and the stated per-case reference boundaries.

Each run retains its prompt, output schema, raw JSONL event log, stderr, final JSON response, invocation command, status, token usage when supplied, elapsed time, and trace-observed suite file paths. The output directory also contains manifests for configuration fingerprints, case-file signatures, run limits, and discovery evidence. The scorer compares per-case IDs and hashes with the current fixture and across conditions, as well as CLI/settings/limit metadata. Mixed combined/separate-arm manifests are rejected as ambiguous. Missing manifests or hashes are marked unknown, not matched; `comparison_ready` requires complete, consistent evidence. Older runs may lack fields added to the harness later; preserve those records and report the gap rather than backfilling guessed provenance.

Before changing a fixture used by historical runs, preserve its exact bytes as `cases-original.jsonl` in that run's output directory without overwriting an existing snapshot. Score those runs with `--cases /absolute/path/to/results/cases-original.jsonl`. Even a reference-filename correction changes fixture and case hashes; it does not mean the corrected metadata was used in the earlier experiment. Keep original prompts, schemas, results, and manifests unchanged.

[score_results.py](score_results.py) produces:

- `comparison.json`: per-case checks, condition totals, loading observations, usage coverage, and limitations.
- `blind-review.json`: paired artifacts labeled A/B without condition names or file lists.
- `blind-key.json`: the separate condition key. Keep it hidden until manual review is complete.

Automatic scoring uses exact numeric/structural expectations and test vectors for supplied code artifacts. Generated Python is **never executed**. A bounded expression interpreter checks the one-return-function subset requested by the coding cases; imports, calls, loops, attributes, and unbounded arithmetic are unsupported. Selected vectors do not prove correctness over every input.

There are 46 discriminating automatic checks. Two null-only output-schema fields are explicitly excluded from the denominator because their values are structurally forced. Review the corresponding uncertainty claims manually. Email date/length checks also provide only partial coverage. These limitations are recorded rather than turning schema conformance into task-quality evidence.

For blind review, assess each answer against the case's `manual_rubric` before opening the key. Record factual errors, unsupported claims, omissions, and task completion; then choose A, B, or tie with a concrete reason. Inspect raw traces for contamination or prohibited actions separately. Labels are hidden, but wording can still reveal a condition; this is not guaranteed experimental blinding.

Failed, timed-out, missing, contaminated, and malformed runs receive zero quality points and remain in the scheduled denominator. Missing token usage is reported as missing coverage, not zero consumption. Input-token totals already include cached input; cached tokens are listed separately and must not be added again. No monetary costs are inferred.

Unreadable or non-object result JSON, missing or malformed completed-response fields, and malformed recorded usage or timing are retained as `invalid_result` with explicit audit issues. They score zero and leave provenance unknown instead of aborting the report. Raw result files are preserved.

An interrupted or malformed JSONL trace does not crash the scorer: valid events remain available, while the loading audit is marked incomplete and comparison readiness stays false. A partial trace cannot establish a clean bypass or absence of unexpected loading; failure status still controls artifact scoring.

Loading is a separate observation, not a quality score. Expected reference IDs and maximum counts are case metadata; preexisting exact specialist skills are allowed. Two simple cases expect no domain reference. Paths are inferred only from completed read commands with exit code zero. Failed or unverified read commands are retained separately and do not count as loaded files. The byte field sums full detected file sizes once: it is an upper bound for partial reads, not a measurement of actual bytes loaded. Indirect paths and other tool reads may be missed. A zero observed read count is not proof of zero loading. Derived reports re-inspect available traces without rewriting raw run records. Raw events and self-reported `files_used` remain available for review.

Report paired quality differences alongside token totals, usage coverage, failures, and latency. These short cases may saturate at full baseline correctness. A tie at the ceiling does not show an improvement, and better routing alone does not establish better task performance. One trial per condition provides no reliable statistical effect estimate.

## Check the tools

```text
python scripts/validate.py --self-test
python evaluations/run_comparison.py --self-test
python evaluations/score_results.py --self-test
python scripts/validate.py
```

The self-checks cover broken and escaping links, unreachable resources, duplicate metadata, missing or nonexact fixture reference paths, configuration preservation, bounded code interpretation, regression detection, and failed-run scoring. The package validator checks plain metadata markers, local inline-link reachability, and package-relative `allowed_references` paths in JSONL fixtures; it is not a general YAML parser, fixture-schema validator, or tokenizer. Run the official SkillMD engine and exact tokenizer checks separately when preparing a release.
