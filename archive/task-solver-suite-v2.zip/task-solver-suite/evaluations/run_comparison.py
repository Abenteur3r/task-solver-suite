#!/usr/bin/env python3
"""Run bounded paired Codex tasks without changing user configuration."""
import argparse
import concurrent.futures
import hashlib
import json
import os
import pathlib
import queue
import random
import re
import signal
import subprocess
import sys
import tempfile
import threading
import time
import tomllib
import unittest

HERE = pathlib.Path(__file__).resolve().parent


def load_cases(path):
    cases = [json.loads(line) for line in pathlib.Path(path).read_text(encoding="utf-8").splitlines() if line.strip()]
    ids = [case["id"] for case in cases]
    if len(ids) != len(set(ids)) or any(not re.fullmatch(r"[a-z0-9-]+", item) for item in ids):
        raise ValueError("Case IDs must be unique lowercase slugs")
    return cases


def output_plan_conflicts(arm, present_manifests, existing_run_names, case_ids):
    errors = []
    if arm == "both" and present_manifests:
        errors.append("Combined runs require a fresh directory without arm manifests")
    if arm != "both" and "both" in present_manifests:
        errors.append("Cannot mix combined and separate-arm manifests")
    if arm in present_manifests:
        errors.append(f"Manifest for {arm} already exists")
    arms = ("baseline", "treatment") if arm == "both" else (arm,)
    conflicts = sorted(f"{case_id}--{condition}" for case_id in case_ids for condition in arms
                       if f"{case_id}--{condition}" in existing_run_names)
    if conflicts:
        errors.append("Run directories already exist: " + ", ".join(conflicts))
    return errors


def toml_value(value):
    if isinstance(value, bool):
        return "true" if value else "false"
    if isinstance(value, str):
        return json.dumps(value, ensure_ascii=True)
    if isinstance(value, (int, float)):
        return str(value)
    if isinstance(value, list):
        return "[" + ",".join(toml_value(item) for item in value) + "]"
    if isinstance(value, dict):
        return "{" + ",".join(json.dumps(key) + "=" + toml_value(item) for key, item in value.items()) + "}"
    raise ValueError(f"Unsupported skills config value: {type(value).__name__}")


def skill_override(config, skill, enabled):
    original = config.get("skills", {}).get("config", [])
    if not isinstance(original, list):
        raise ValueError("skills.config must be an array")
    target = os.path.normcase(str(pathlib.Path(skill).resolve()))
    entries = [dict(item) for item in original if os.path.normcase(str(pathlib.Path(item["path"]).expanduser().resolve())) != target]
    entries.append({"path": str(pathlib.Path(skill).resolve()), "enabled": enabled})
    return "skills.config=" + toml_value(entries)


def stop(process):
    if process.poll() is not None:
        return
    if os.name == "nt":
        subprocess.run(["taskkill", "/PID", str(process.pid), "/T", "/F"], capture_output=True, timeout=10)
    else:
        os.killpg(process.pid, signal.SIGTERM)
    try:
        process.wait(timeout=5)
    except subprocess.TimeoutExpired:
        process.kill()


def launch(command, cwd):
    options = {"creationflags": subprocess.CREATE_NEW_PROCESS_GROUP} if os.name == "nt" else {"start_new_session": True}
    return subprocess.Popen(command, cwd=cwd, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                            stderr=subprocess.PIPE, text=True, encoding="utf-8", errors="replace", **options)


def probe(cli, cwd, override, skill):
    process = launch([str(cli), "-c", override, "app-server"], cwd)
    lines, errors = queue.Queue(), []
    threading.Thread(target=lambda: [lines.put(line) for line in process.stdout], daemon=True).start()
    threading.Thread(target=lambda: [errors.append(line[:1000]) for line in process.stderr], daemon=True).start()

    def send(message):
        process.stdin.write(json.dumps(message) + "\n")
        process.stdin.flush()

    def receive(identifier):
        deadline = time.monotonic() + 30
        while time.monotonic() < deadline:
            try:
                message = json.loads(lines.get(timeout=0.25))
            except queue.Empty:
                if process.poll() is not None:
                    break
                continue
            if message.get("id") == identifier:
                if "error" in message:
                    raise RuntimeError(message["error"])
                return message["result"]
        raise RuntimeError("skills/list probe failed: " + "".join(errors[-3:]))

    try:
        send({"id": 0, "method": "initialize", "params": {"clientInfo": {"name": "task_solver_evaluation", "version": "2.0.0"}}})
        receive(0)
        send({"method": "initialized", "params": {}})
        send({"id": 1, "method": "skills/list", "params": {"cwds": [str(cwd)], "forceReload": True}})
        result = receive(1)
        matches = [item for entry in result["data"] for item in entry["skills"] if item["name"] == "task-solver-suite"]
        if len(matches) != 1 or pathlib.Path(matches[0]["path"]).resolve() != pathlib.Path(skill).resolve():
            raise RuntimeError("Expected exactly the installed task-solver-suite, without extra discovery roots")
        if matches[0]["scope"] != "user":
            raise RuntimeError("Expected personal USER scope")
        return {key: matches[0][key] for key in ("name", "path", "scope", "enabled")}
    finally:
        stop(process)


def schema_for(value):
    if value is None:
        return {"type": "null"}
    if isinstance(value, bool):
        return {"type": "boolean"}
    if isinstance(value, (int, float)):
        return {"type": "number"}
    if isinstance(value, str):
        return {"type": "string"}
    if isinstance(value, list):
        return {"type": "array", "items": schema_for(value[0] if value else "")}
    return {"type": "object", "properties": {key: schema_for(item) for key, item in value.items()},
            "required": list(value), "additionalProperties": False}


def matches_shape(value, schema):
    kind = schema["type"]
    if kind == "object":
        return isinstance(value, dict) and set(value) == set(schema["properties"]) and all(matches_shape(value[key], child) for key, child in schema["properties"].items())
    if kind == "array":
        return isinstance(value, list) and all(matches_shape(item, schema["items"]) for item in value)
    if kind == "null":
        return value is None
    if kind == "boolean":
        return isinstance(value, bool)
    if kind == "number":
        return isinstance(value, (int, float)) and not isinstance(value, bool)
    return isinstance(value, str)


def observed_reads(events, skill_root):
    paths, commands, violations, unverified = set(), [], [], []
    known = [p for p in skill_root.rglob("*.md") if p.is_file()]
    for event in events:
        item = event.get("item", {})
        if event.get("type") != "item.completed" or item.get("type") != "command_execution":
            continue
        command = item.get("command", "")
        commands.append(command)
        normal = re.sub(r"/+", "/", command.replace("\\", "/")).lower()
        if "evaluations/" in normal or "cases.jsonl" in normal or "score_results.py" in normal:
            violations.append("Evaluation assets appear in a command")
        if not re.search(r"get-content|\bcat\b|\btype\b|\bsed\b|\bhead\b|\btail\b|read_text|readfile", normal):
            continue
        if item.get("exit_code") != 0 or item.get("status") != "completed":
            unverified.append(command)
            continue
        for path in known:
            relative = path.relative_to(skill_root).as_posix()
            if path.as_posix().lower() in normal or ("task-solver-suite" in normal and relative.lower() in normal):
                paths.add(relative)
    return {
        "trace_observed_suite_files": sorted(paths),
        "detected_file_bytes_upper_bound": sum((skill_root / path).stat().st_size for path in paths),
        "commands": commands,
        "unverified_or_failed_read_commands": unverified,
        "evaluation_asset_violations": sorted(set(violations)),
        "read_detection_limit": "Successful read-command paths only, not filesystem auditing. Byte total sums full detected file sizes once, an upper bound for partial reads, not actual bytes loaded; other tools and indirect paths may be missed.",
    }


def run_case(case, arm, args, override):
    output = pathlib.Path(args.output_dir).resolve()
    label = f"{case['id']}--{arm}"
    run_dir = output / label
    run_dir.mkdir()
    workspace = run_dir / "workspace"
    workspace.mkdir()
    schema = schema_for({"artifact": case["shape"], "explanation": "", "files_used": [""]})
    schema_path = run_dir / "output-schema.json"
    schema_path.write_text(json.dumps(schema), encoding="utf-8")
    response_path = run_dir / "response.json"
    prompt = ("$task-solver-suite\n" if arm == "treatment" else "") + case["task"] + "\n\n"
    prompt += ("Return the requested task artifact in the output schema, a brief explanation (at most 150 words), "
               "and files_used listing only instruction/reference files actually read. This task is read-only: "
               "do not modify files, contact network/services, delegate, deploy, or submit anything. "
               "Use only the supplied task facts and relevant installed skill instructions. "
               "Do not inspect evaluation cases, scoring code, expected answers, or earlier result files. "
               "If the task needs no additional reference, solve it directly. Do not claim tests you did not execute.")
    (run_dir / "prompt.txt").write_text(prompt, encoding="utf-8")
    command = [str(args.cli), "-a", "never", "-c", override, "exec", "--ephemeral", "--json",
               "--sandbox", "read-only", "--skip-git-repo-check", "--cd", str(workspace),
               "--output-schema", str(schema_path), "--output-last-message", str(response_path), "-"]
    start = time.monotonic()
    result = {"case_id": case["id"], "arm": arm, "status": "starting", "command": command,
              "case_sha256": hashlib.sha256(json.dumps(case, sort_keys=True).encode()).hexdigest(),
              "artifact_contract": "JSON final response, not a model-created file or deployed artifact"}
    process = None
    try:
        process = launch(command, workspace)
        process.stdin.write(prompt)
        process.stdin.close()
        exceeded = threading.Event()

        def copy(stream, destination):
            total = 0
            with destination.open("w", encoding="utf-8") as out:
                for line in stream:
                    total += len(line.encode("utf-8"))
                    if total > args.max_log_bytes:
                        exceeded.set()
                        break
                    out.write(line)

        readers = [threading.Thread(target=copy, args=(process.stdout, run_dir / "events.jsonl"), daemon=True),
                   threading.Thread(target=copy, args=(process.stderr, run_dir / "stderr.txt"), daemon=True)]
        for reader in readers:
            reader.start()
        while process.poll() is None and time.monotonic() - start < args.timeout and not exceeded.is_set():
            time.sleep(0.2)
        if exceeded.is_set():
            result["status"] = "output_limit"
            stop(process)
        elif process.poll() is None:
            result["status"] = "timeout"
            stop(process)
        else:
            result["status"] = "completed" if process.returncode == 0 else "execution_failed"
        for reader in readers:
            reader.join(timeout=5)
        result["exit_code"] = process.poll()
        events = []
        for line in (run_dir / "events.jsonl").read_text(encoding="utf-8").splitlines():
            try:
                events.append(json.loads(line))
            except json.JSONDecodeError:
                pass
        completed = [event for event in events if event.get("type") == "turn.completed"]
        result["usage"] = completed[-1].get("usage") if completed else None
        result.update(observed_reads(events, pathlib.Path(args.skill).resolve().parent))
        if result["status"] == "completed":
            if not completed:
                result["status"] = "missing_completion"
            elif not response_path.is_file():
                result["status"] = "missing_response"
            else:
                try:
                    response = json.loads(response_path.read_text(encoding="utf-8"))
                    if matches_shape(response, schema):
                        result["response"] = response
                    else:
                        result["status"] = "invalid_contract"
                        result["invalid_response"] = response
                except (UnicodeError, json.JSONDecodeError):
                    result["status"] = "invalid_json"
        if result.get("evaluation_asset_violations"):
            result["status"] = "contaminated"
    except Exception as exc:
        result["status"] = "harness_error"
        result["error"] = str(exc)
    finally:
        if process is not None:
            stop(process)
        result["wall_seconds"] = round(time.monotonic() - start, 3)
        (run_dir / "result.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(json.dumps({key: result.get(key) for key in ("case_id", "arm", "status", "wall_seconds", "usage")}), flush=True)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--cli", type=pathlib.Path, required=True)
    parser.add_argument("--skill", type=pathlib.Path, required=True, help="Installed personal SKILL.md")
    parser.add_argument("--cases", type=pathlib.Path, default=HERE / "cases.jsonl")
    parser.add_argument("--arm", choices=("baseline", "treatment", "both"), default="both")
    parser.add_argument("--output-dir", type=pathlib.Path, required=True)
    parser.add_argument("--concurrency", type=int, choices=(1, 2), default=2)
    parser.add_argument("--timeout", type=int, default=180)
    parser.add_argument("--max-log-bytes", type=int, default=8_000_000)
    parser.add_argument("--probe-only", action="store_true")
    args = parser.parse_args()
    if not 1 <= args.timeout <= 180 or not 1024 <= args.max_log_bytes <= 16_000_000:
        parser.error("Use a timeout of 1..180 seconds and a log limit of 1024..16000000 bytes")
    if not args.cli.is_file() or not args.skill.is_file():
        parser.error("CLI executable and installed SKILL.md must exist")
    output = args.output_dir.resolve()
    if output.is_relative_to(HERE.parent) or output.is_relative_to(args.skill.resolve().parent):
        parser.error("Keep evaluation outputs outside both the source and installed skill packages")
    output.mkdir(parents=True, exist_ok=True)
    cases = load_cases(args.cases)
    if not args.probe_only:
        present = {p.stem.removeprefix("manifest-") for p in output.glob("manifest-*.json")}
        existing = {p.name for p in output.iterdir() if p.is_dir()}
        conflicts = output_plan_conflicts(args.arm, present, existing, [case["id"] for case in cases])
        if conflicts:
            raise FileExistsError("; ".join(conflicts))
    config_home = pathlib.Path(os.environ.get("CODEX_HOME", str(pathlib.Path.home() / ".codex")))
    config_file = config_home / "config.toml"
    config_bytes = config_file.read_bytes() if config_file.exists() else b""
    config = tomllib.loads(config_bytes.decode("utf-8"))
    overrides = {arm: skill_override(config, args.skill, arm == "treatment") for arm in ("baseline", "treatment")}
    arms = ("baseline", "treatment") if args.arm == "both" else (args.arm,)
    with tempfile.TemporaryDirectory(prefix="suite-discovery-") as temporary:
        discovery = {arm: probe(args.cli.resolve(), pathlib.Path(temporary), overrides[arm], args.skill) for arm in arms}
    for arm, found in discovery.items():
        if found["enabled"] != (arm == "treatment"):
            raise RuntimeError(f"Suite enabled state is wrong for {arm}")
    print(json.dumps({"discovery": discovery}), flush=True)
    if args.probe_only:
        return
    manifest = {
        "arm": args.arm, "case_count": len(cases), "discovery": discovery,
        "cases_sha256": hashlib.sha256(args.cases.read_bytes()).hexdigest(),
        "case_ids": [case["id"] for case in cases],
        "config_sha256": hashlib.sha256(config_bytes).hexdigest(),
        "default_model": config.get("model"), "reasoning_effort": config.get("model_reasoning_effort"),
        "cli_version": subprocess.run([str(args.cli.resolve()), "--version"], capture_output=True, text=True).stdout.strip(),
        "skill_sha256": hashlib.sha256(args.skill.read_bytes()).hexdigest(),
        "timeout_seconds": args.timeout, "concurrency": args.concurrency,
        "other_skills": "Existing configuration retained; only task-solver-suite enabled state changes.",
    }
    manifest_path = output / f"manifest-{args.arm}.json"
    if manifest_path.exists():
        raise FileExistsError(f"Refusing to replace {manifest_path}; choose a fresh output directory")
    manifest_path.write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    jobs = [(case, arm) for case in cases for arm in arms]
    if args.arm == "both":
        random.Random(1729).shuffle(jobs)
    with concurrent.futures.ThreadPoolExecutor(max_workers=args.concurrency) as pool:
        futures = [pool.submit(run_case, case, arm, args, overrides[arm]) for case, arm in jobs]
        results = [future.result() for future in concurrent.futures.as_completed(futures)]
    raise SystemExit(0 if all(result["status"] == "completed" for result in results) else 1)


class RunnerChecks(unittest.TestCase):
    def test_preserves_other_disabled_entries(self):
        config = {"skills": {"config": [{"path": "unrelated/SKILL.md", "enabled": False}]}}
        merged = tomllib.loads(skill_override(config, "task-solver-suite/SKILL.md", False))
        self.assertEqual(merged["skills"]["config"][0], config["skills"]["config"][0])
        self.assertEqual(len(config["skills"]["config"]), 1)
        self.assertFalse(merged["skills"]["config"][1]["enabled"])

    def test_shape_is_type_only(self):
        self.assertEqual(schema_for(42), {"type": "number"})
        self.assertNotIn("const", json.dumps(schema_for({"answer": "gold answer"})))

    def test_bool_toml(self):
        self.assertEqual(tomllib.loads("x=" + toml_value([{"enabled": False}])), {"x": [{"enabled": False}]})

    def test_malformed_response(self):
        schema = schema_for({"value": 3})
        self.assertFalse(matches_shape({"value": True}, schema))
        self.assertFalse(matches_shape([], schema))
        self.assertTrue(matches_shape({"value": 8}, schema))

    def test_rerun_preflight_rejects_mixed_modes(self):
        self.assertTrue(output_plan_conflicts("both", {"baseline", "treatment"}, {"case--baseline"}, ["case"]))
        self.assertTrue(output_plan_conflicts("treatment", {"both"}, set(), ["case"]))
        self.assertTrue(output_plan_conflicts("baseline", set(), {"case--baseline"}, ["case"]))
        self.assertEqual(output_plan_conflicts("treatment", {"baseline"}, {"case--baseline"}, ["case"]), [])

    def test_failed_read_is_not_loaded(self):
        root = HERE.parent
        command = f'Get-Content "{root / "SKILL.md"}"'
        event = {"type": "item.completed", "item": {"type": "command_execution", "command": command, "exit_code": 1, "status": "failed"}}
        failed = observed_reads([event], root)
        self.assertEqual(failed["trace_observed_suite_files"], [])
        self.assertEqual(failed["detected_file_bytes_upper_bound"], 0)
        event["item"].update(exit_code=0, status="completed")
        succeeded = observed_reads([event], root)
        self.assertEqual(succeeded["trace_observed_suite_files"], ["SKILL.md"])


if __name__ == "__main__":
    if sys.argv[1:] == ["--self-test"]:
        unittest.main(argv=[__file__])
    else:
        main()
