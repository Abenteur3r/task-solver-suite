---
name: task-solver-suite
description: Route complex, ambiguous, or cross-domain tasks to focused workflows for software, data, research, product, documents, operations, and difficult decisions. Use when work needs decomposition, evidence, trade-off resolution, or coordinated deliverables. Select only relevant modules; handle simple edits, translations, calculations, and factual replies directly.
license: MIT
metadata:
  version: "2.0.0"
---

# Task Solver Suite

Complete the user's requested outcome using the smallest useful workflow. This is a selective router: its modules supply missing decision procedures, not a checklist to execute on every task.

## Select before loading

1. Identify the requested deliverable, existing artifacts, hard constraints, and what is uncertain. Use supplied context before asking questions. Ask only about gaps that change the next decision; continue independent work while waiting.
2. For a simple, unambiguous operation, do it directly. A typo fix, straightforward translation, one-step calculation, or answer already established by supplied evidence needs no domain module.
3. Respect any explicitly requested skill. If an available specialist already covers the exact workflow, use it for that workflow; avoid loading the suite's equivalent instructions as well. Discover actual capabilities from the current environment rather than assuming named tools exist.
4. Otherwise choose **one primary route** below by the immediate deliverable or current blocker. Read that file, then act. A keyword in background context is insufficient: a pitch about an ML product remains a pitch task unless model validation is also requested.
5. Add a second module only for a concrete dependency, failed check, or separately requested deliverable. State its purpose briefly when the change matters. For a large mixed task, work through required routes sequentially; do not preload the whole catalog or all templates.

Paths resolve relative to this skill directory. Read references as needed; copy templates into the user's project only when a saved working document is useful within the request. Installed instructions are not the destination for task outputs.

## Route by outcome

| Immediate task or blocker | Read | Completion evidence |
| --- | --- | --- |
| Implement or refactor behavior in an existing codebase | [Software implementation](references/08-software-implementation.md) | Working change, affected callers, relevant checks |
| Diagnose a failure, regression, or performance problem | [Debugging and performance](references/09-debugging-and-performance.md) | Reproduction, supported cause, verified correction |
| Design interfaces, components, APIs, or system boundaries | [Architecture and interfaces](references/10-architecture-and-interfaces.md) | Contracts, failure behavior, justified decision |
| Review security, permissions, sensitive data, or a concrete trust boundary | [Security and privacy](references/11-security-and-privacy.md) | Threat-specific findings and tested controls |
| Deploy, migrate, automate, schedule, or operate a service/workflow | [Operations and automation](references/12-operations-and-automation.md) | Verified state, bounded retries, recovery |
| Develop or assess an on-chain contract or transaction flow | [Blockchain and contracts](references/13-blockchain-and-contracts.md) | Invariants, network/units, tests, observed state |
| Analyze data, write SQL, explain a metric, or assess an experiment | [Data analysis and statistics](references/14-data-analysis-and-statistics.md) | Correct grain/denominator, reproducible result |
| Train, validate, compare, or deploy predictive models | [Predictive ML](references/02-predictive-ml-zero-leakage.md) | Valid split, comparable evidence, verified inference |
| Make a modality-specific ML or model-lifecycle decision | [ML modalities and lifecycle](references/15-ml-modalities-and-lifecycle.md) | Appropriate representation and lifecycle checks |
| Build or evaluate generation, retrieval, tools, or agents | [GenAI, agents, and RAG](references/03-genai-agent-rag-architecture.md) | Measured success, bounded execution, evidence/fallback |
| Research a question, verify a claim, or compare external options | [Research and evidence](references/16-research-and-evidence.md) | Traceable sources, fair comparison, bounded conclusion |
| Choose product scope, prioritize work, or plan a project | [Product and project planning](references/17-product-and-project-planning.md) | Outcome, evidence, dependencies, feasible milestone |
| Build a usable interface or a quick working prototype | [Prototyping and UI](references/04-rapid-prototyping-and-ui.md) | Complete core journey and user-visible states |
| Create or edit a document, spreadsheet, slide deck, or PDF | [Documents and artifacts](references/18-documents-spreadsheets-and-slides.md) | Correct editable artifact and format-specific checks |
| Solve a mathematical, scientific, quantitative, or optimization problem | [Quantitative problem solving](references/19-quantitative-problem-solving.md) | Correct model, units, checked result |
| Untangle uncertain causes, competing options, or a difficult argument | [Thinking-method selection](references/20-thinking-method-selection.md) | One selected method and decision-relevant artifact |
| Improve one requirement without violating another | [TRIZ trade-offs](references/05-triz-hackathon-tradeoffs.md) | Measurable contradiction, separation, tested result |
| Write, edit, summarize, translate, or adapt content | [Writing and localization](references/27-writing-and-localization.md) | Faithful content for the requested audience/form |
| Prepare a pitch, demo script, or judge defense | [Pitching and demo](references/07-pitching-demo-and-judging.md) | Timed narrative with traceable claims |
| Run an event with competition rules, scoring, and a deadline | [Hackathon sprint](references/28-hackathon-sprint.md) | Valid entry and verified five-stage delivery |
| Teach, explain, design practice, or diagnose misunderstanding | [Learning and explanation](references/29-learning-and-explanation.md) | Matched explanation and evidence of understanding |
| Interpret health, legal, financial, or safety-critical material for a consequential decision | [Domain-sensitive decisions](references/30-domain-sensitive-decisions.md) | Correct scope, authoritative evidence, explicit limits |

For an uncovered specialty, identify the domain/output, inspect an available specialist or primary documentation, and adapt the closest workflow. Mark missing expertise or evidence; a module title is not a qualification or proof of correctness.

## Keep additions conditional

- For **ML**, add [modalities/lifecycle](references/15-ml-modalities-and-lifecycle.md) when representation, prediction horizon, serving parity, or lifecycle is the unresolved issue. Do not load it merely because a dataset has a modality.
- For an **unresolved contradiction**, use [40 inventive principles](references/25-triz-inventive-principles.md) to generate mechanisms or [deep contradiction analysis](references/26-ariz-deep-contradictions.md) to reconstruct the problem. If supplied evidence already establishes failed separation attempts, enter the relevant deeper route directly; preserve that evidence rather than repeating the lightweight process. Load a principle catalog only when mechanisms are missing.
- For a **material delivery risk**, add [premortem and fail-safes](references/06-premortem-risk-and-fail-safes.md). Routine low-impact work does not need a risk ceremony.
- For **competition framing**, the sprint route points to [triage and scoring](references/01-hackathon-triage-and-scoring.md). Ordinary projects use their acceptance criteria without inventing judges, leaderboards, or pitches.
- For a **specialized artifact/platform**, prefer its installed skill and actual tool documentation for execution mechanics. Use this suite for any remaining reasoning gap, not a second parallel workflow.

## Execute at the scale of the task

**Frame:** Define the requested result and a checkable completion condition. For complex work, record assumptions, dependencies, budget, and recovery in the [task contract](templates/task_contract_template.md). A simple request can keep this implicit.

**Establish evidence:** Inspect actual input or failing behavior. Use a baseline, small example, source inspection, or vertical slice suited to the task. Keep facts, measurements, estimates, and hypotheses distinct.

**Act:** Make the smallest complete change or discriminating experiment. Preserve existing valid work. Use the [decision record](templates/decision_record_template.md) for consequential choices, [research ledger](templates/research_evidence_template.md) for contested evidence, and [experiment backlog](templates/ml_hypothesis_backlog_template.md) for repeated experiments when needed.

**Verify:** Test the actual output against the completion condition. Check important edge cases and changed boundaries; rerun checks when relevant changes/failures justify it. A linter, plausible narrative, or model self-assessment does not substitute for task evidence.

**Deliver:** Provide the usable result, decisive evidence, and material limitations. Distinguish prepared artifacts from deployed services or accepted submissions. Confirm external state after authorized remote effects; preserve authorization already given within its scope.

## Routing discipline

Do not expand the assignment because another module looks relevant. Stay with the selected route until the deliverable changes or evidence reveals another blocker. Retain useful findings when switching and identify what the new route resolves. Stop loading when enough guidance exists to act.

Prefer available task-specific tools over inventing wrappers. Instructions require no package, network service, particular model, or agent team to read. Optional validation/evaluation tools maintain this skill; they are not prerequisites for solving the user's task.

Report the outcome rather than a catalog of methods. Explain routing only when requested, when a decision needs justification, or when explicitly evaluating routing.
