# Validation record

Validated on 2026-10-26 for version **2.0.0**. This report separates package checks, observed routing, artifact quality, and client integration. The earlier v1 installation was backed up before updating.

## Package and format

| Check | Result |
| --- | --- |
| Package inventory | 48 authored files: 42 Markdown files, one license, three Python tools, two JSONL fixtures |
| Selective coverage | 22 outcome routes, 30 reference modules, seven optional templates |
| Method inventory | 31 thinking-method cards, 40 TRIZ principles, nine-stage practical ARIZ adaptation |
| Agent Skills metadata | Valid YAML, supported fields, matching folder/name, version 2.0.0 |
| Bundled skill-creator validator | Pass: Skill is valid! |
| Official SkillMD engine | 100/100, ok: true, no diagnostics |
| Root scan classification | docs_only; a pattern scan, not a security audit |
| Root size | 10,214 bytes, 78 lines |
| Exact root token count | 2,002 cl100k_base; 1,998 o200k_base; below the 6,000-token requirement |
| Local link and reachability check | Pass; all local targets exist within the package; all 37 references/templates reachable |
| Maintenance-tool regression checks | 19 passed: package validator 5, runner 6, scorer 8 |

Root SKILL.md SHA-256:

    10f6db320614160f7d20d2b7cd73ae744c8ba78ee81eadd866877e3611d7bc93

The official @skillmds/core 1.0.0 engine was called directly with the package slug and checked for a successful result without warnings; the CLI executable was not used. Exact token counts used tiktoken. PyYAML and the bundled quick_validate.py checked metadata separately. Maintenance dependencies remained outside the package; the skill instructions need no runtime packages. The shipped validator checks metadata markers and local inline-link reachability, and is not a general YAML parser or tokenizer.

Independent review found and repaired three evaluation-tool defects: unchecked protocol differences, failed reads counted as loaded files, and metadata written before existing-run detection. A fourth regression check now handles partial JSONL without discarding valid events or incorrectly treating an interrupted trace as complete. Missing provenance blocks comparison readiness, failed runs remain in the scheduled denominator, and detected full-file sizes are explicitly an upper bound rather than bytes actually loaded. A narrow follow-up review confirmed these repairs.

## Complete file-structure and instruction audit

On 2026-10-26, every authored file was read for its role, internal structure, and consistency with the root routing contract. Three independent review scopes covered references and supporting tools; the primary review covered the root documents and package-wide checks.

| Files covered | Count | Review focus |
| --- | ---: | --- |
| SKILL.md, README.md, SOURCES.md, VALIDATION.md, LICENSE | 5 | Metadata, routing, installation examples, provenance, claims and packaging |
| References 01–15 | 15 | Entry conditions, technical procedures, scope boundaries and completion evidence |
| References 16–30 | 15 | Method selection, catalog consistency, conditional loading and task-specific completion |
| All templates | 7 | Required fields, usable output structure, callers and conditional use |
| scripts/validate.py | 1 | Checks, error reporting and regression coverage |
| Evaluation README, runner, scorer and both JSONL fixtures | 5 | Documented CLI, data contracts, scoring and evidence preservation |
| Total | 48 | All authored files covered |

The mechanical audit verified UTF-8 across all 48 files; one top-level heading, balanced code fences, consistent table widths and heading levels in all 42 Markdown files; Python syntax in all three tools; and valid JSON with unique case IDs in both fixtures. All 96 local Markdown destinations match filename case exactly, all 37 reference/template resources are reachable, and all 28 declared module paths in the 18 evaluation records resolve within the package. Catalog numbering matches 31 method cards, forty principles, and nine deep-analysis stages.

The audit found and corrected issues beyond ordinary Markdown lint:

- Nine modules had instructions that could expand a focused request: ordinary ML inherited competition delivery gates (02), local UI inherited shared-URL/judge checks (04), risk planning inherited rehearsal/execution requirements (06), pitch-only work inherited demo/Q&A/rehearsal requirements (07), security review implied repairs (11), transaction diagnosis implied contract compilation/testing (13), a reference-only TRIZ request implied an experiment (25), presentation work loaded both templates (28), and explanation/hint requests implied exercises (29). These actions are now conditional on the actual task, while applicable completion checks remain.
- Two allowed-reference filenames in the paired fixtures were stale. They now match the actual diagnosis and decision catalog filenames. The package validator checks these paths and has a missing/case-mismatched-path regression test.
- A truncated or non-object result.json could stop the whole scoring report. The scorer now records malformed results as zero-scoring failures, marks audit/provenance uncertainty, and retains the scheduled denominator. The focused regression also covers malformed response/usage fields.
- Historical v1 wording in the source ledger could be read as describing current TRIZ coverage. It now explicitly distinguishes the two versions.

The changed clauses were reread against the affected narrow requests. Relevant tool regressions passed, the root again passed quick_validate and SkillMD at 100/100, and the final personal installation was synchronized and checked by hash. The pre-audit v2 installation was preserved in a separate temporary backup. No additional model sessions were run for this structural audit; it establishes inspected structure and corrected instruction scope, not a new behavioral efficacy result.

The original paired fixture was preserved as cases-original.jsonl in the historical evaluation output before correcting its reference metadata (SHA-256: cc62b5151518164890afd660568b0bf47ed8430cffe95ce4eab38fbcf115b6a9). Prompts, output shapes, and scoring checks did not change. Rescoring all 24 historical runs with that frozen fixture retained 46/46 checks per arm and the same usage/time totals. Use that snapshot to reproduce the historical comparison; the corrected fixture intentionally has different hashes for two records.

## Routing design and boundary review

The root chooses by the requested deliverable and current blocker, starts with one relevant module, and adds another only for a concrete dependency. Simple operations bypass domain modules. An exact available specialist takes precedence over duplicating its workflow. Templates are optional; catalogs are not bulk-loaded.

An 18-scenario boundary review covered simple corrections/translations/calculations, code and artifacts with existing specialist skills, ML pitches, forecasting, migration, and resumed contradiction analysis. It led to two root clarifications: a pitch about ML stays a pitch task, and previously failed separation attempts allow direct entry to deep TRIZ. This was an instruction review, not an 18-run model benchmark.

The original five-stage competition workflow remains available as a dedicated route. The broader modules cover software, operations, security, data, ML, GenAI, research, product, documents, communication, quantitative work, learning, and consequential decisions. Breadth is not a claim of professional qualification or exhaustive domain expertise. The ARIZ material is an original practical adaptation, not the full formal method or a certification.

## Paired artifact evaluation

The [evaluation design](evaluations/README.md) and [12 fixtures](evaluations/cases.jsonl) are shipped for reproduction. Each case ran once in a fresh read-only ephemeral Codex session with the same facts and output schema. Baseline disabled only this suite; treatment enabled it and explicitly invoked its name. Other configured skills remained available. Neither condition overrode the configured model or reasoning settings.

| Observed measure | Baseline | With suite |
| --- | ---: | ---: |
| Completed cases | 12/12 | 12/12 |
| Discriminating automatic checks | 46/46 | 46/46 |
| Input tokens, including cached input | 260,563 | 245,125 |
| Cached input already included above | 36,864 | 0 |
| Output tokens | 2,076 | 2,584 |
| Median elapsed seconds | 10.969 | 13.961 |

The checks cover supplied code vectors, numeric/structural results, and explicit task constraints. Generated code was inspected by a bounded expression interpreter, never executed. Two null-only schema fields were excluded from the score because schema conformance already forces their values.

A separate reviewer saw condition-hidden paired answers without the key. All 12 comparisons were ties, with no serious errors identified. The debugging answers shared a minor omission: they did not explicitly propose regression tests, although the code passed the supplied vectors.

**No quality improvement was demonstrated.** Both conditions reached the ceiling of these short fixtures. Treatment's uncached input was about 9.6% higher, output 24.5% higher, and median elapsed time 27.3% higher in these observations. Different cache behavior, separate-arm timing, and one trial per case prevent a reliable causal speed, cost, or quality estimate. The resolved server model was not independently exposed; configured defaults are recorded as such.

No treatment run issued a command to read a domain reference in these 12 short cases. This supports the observed lightweight behavior on these prompts, not the efficacy of the domain modules. Automatic root injection and indirect reads are outside the command-path detector; zero observed reads is not proof of zero loading.

The stricter final scorer reports comparison_ready: false with no detected protocol differences and four provenance unknowns: the original baseline and treatment manifests each lack case_ids and cases_sha256 fields added later. Existing per-case hashes, prompt bodies, and schema bodies were independently checked and matched. Raw manifests were preserved without backfilling. The table above records observed outcomes; it is not a fully provenance-complete benchmark. Future runs record and enforce these additional fields.

## Complex Russian-language routing exercises

Six [complex routing fixtures](evaluations/routing_cases.jsonl) ran separately against the personal installation. These are routing smoke checks and manually reviewed task artifacts, without a baseline arm or automatic quality score.

| Requested result | Successfully read domain references | Review |
| --- | --- | --- |
| RAG with changing access rights and latency limits | 03 GenAI/RAG | Authorization-aware cache and retrieval, approval-bound action, bounded degraded path |
| Forecast protocol with delayed/revised data and new stores | 02 ML validation + 15 modalities/lifecycle | As-of replay, temporal/entity separation, four horizons, baseline and serving parity; clarification described below |
| Live migration with concurrent writes and duplicate email | 12 operations + 10 architecture | Compatibility, change capture, idempotency, reconciliation and realistic rollback |
| Deep contradiction after earlier failed approaches | 26 deep TRIZ | Resumed directly; concrete mechanisms and falsifying tests |
| Pitch for an already evaluated ML product | 07 pitching | 90-second script and exactly two answers; no model rebuild or invented effects |
| Research recommendation from conflicting benchmarks | 16 research | Preserved incompatible study conditions; conditional recommendation and common-corpus pilot |

All six completed. Traces contained nine successful read commands, eight domain-reference reads in total, no failed read commands, no detected unrelated references, and no case beyond its stated reference budget. The pitch also loaded the two relevant pitch/Q&A templates. These are successful command observations, not complete filesystem telemetry.

Input was 305,637 tokens including 164,608 cached input; output was 14,408 tokens; median elapsed time was 78.929 seconds. These larger requests are not comparable to the short paired fixtures.

Independent review found no serious artifact errors or false claims of executed validation. The forecast answer did need clearer terminology: development-unseen labels may guide model selection, whereas final-unseen labels must remain isolated; seen status must be determined from actual training contribution at each forecast origin.

Reference 15 was amended. An exact-prompt regression used byte-identical prompt/schema and the same case hash. It successfully read only references 02 and 15 and explicitly resolved both distinctions. Two reviewers confirmed the correction. The run took 118.813 seconds and used 70,005 input tokens including 44,288 cached, plus 3,326 output tokens. A final editorial clarification also requires baseline information access to match the candidate model, including the peer/global fallback under strict zero-shot evaluation; this sentence was added after the model regression and was not subjected to another model run.

The first forecast regression attempt was interrupted before producing a final result. Its partial trace was preserved and its usage remains unknown. Total v2 evaluation accounting is **31 completed model sessions and one interrupted attempt**: 24 paired, six complex routing, one completed regression, and the interrupted regression attempt.

## Personal Codex installation

The complete v2 package is installed at ~/.agents/skills/task-solver-suite. All 48 installed authored files match the repository source by SHA-256. The previous v1 package was backed up; no user Codex configuration was changed.

Codex 0.164.0-alpha.11.1 app-server skills/list, with forceReload and no extra discovery roots, returned exactly one matching entry with scope user and enabled true. The evaluation runner rechecked discovery before model execution. Fresh ephemeral sessions explicitly invoking $task-solver-suite read the personal installation's selected references and returned the requested artifacts. The current chat's available-skill catalog also advertises the v2 description.

This verifies personal discovery and explicit invocation in the tested Codex runtime. It does not guarantee automatic selection for every natural-language request. Native discovery/execution in Claude Code, Cursor, OpenCode, Gemini CLI, and Antigravity were not tested; their installation paths and documentation are recorded in the README. PowerShell and Git Bash copy/preservation examples were tested on the earlier 16-file v1 package; v2 installation was checked by full-content hash parity.

## Evidence locations and remaining limits

Raw local records are retained outside the installable package under the operating-system temporary directory:

- task-solver-v2-evaluation: paired raw events, responses, manifests, derived comparison, blind-review packet and trace audit.
- task-solver-v2-routing-20261026: six routing outputs and routing-audit.json.
- task-solver-v2-forecast-regression-20261026: interrupted attempt and interruption-note.json.
- task-solver-v2-forecast-regression-20261026-retry1: completed regression and regression-audit.json.

These local records are not bundled and may be removed by ordinary temporary-directory cleanup. The fixture files, runner, scorer and this report remain in the repository.

The tests produced task answers, plans, protocols, code snippets and scripts as JSON responses. They did not execute production migrations, train models, deploy services, perform live demonstrations, or prove correctness on long projects. No native cross-client or multi-model efficacy study was performed. Routing depends on the host and model following the instructions; the suite does not install OS hooks. Long-task quality, repeated-run reliability, current external-domain facts, and actual project outcomes still require task-specific evidence.
