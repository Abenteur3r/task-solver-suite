# Task Solver Suite

A portable Agent Skill for complex software, data, research, product, artifact, operational, and decision tasks. Version 2 broadens the original competition suite while keeping one lightweight entry point and selective reference loading.

The name is `task-solver-suite`. Its main job is to identify the immediate deliverable, select the relevant guidance, complete the work, and verify the result. Instructions require no packages, network access, API keys, MCP servers, or particular model. Project implementation tools and optional suite-maintenance tests have their own prerequisites.

## How selective loading works

1. The host initially sees one skill name and a short description.
2. The [root router](SKILL.md) identifies the actual deliverable and current blocker. Simple edits, direct translations, arithmetic, and supplied facts bypass domain modules.
3. A matching specialist already available in the environment handles its exact workflow. Otherwise, the router selects one primary reference.
4. Additional references load only for a concrete dependency, failed check, or another requested deliverable. Complex mixed work progresses through routes as needed.
5. Templates are copied only when a saved working artifact is useful. Method catalogs and evaluation assets are not loaded for ordinary task execution.

This is model-driven skill selection and progressive disclosure. It does not install operating-system hooks, intercept every prompt, or guarantee that a host will always select the correct route. The validation and evaluation tools make observed mistakes and unnecessary loading visible.

## Coverage

| Area | Focus |
| --- | --- |
| Software | Implementation/refactoring, diagnosis, performance, architecture/interfaces, security/privacy |
| Operations | Deployment, migrations, automation, recovery, blockchain contracts and transaction state |
| Data and AI | SQL/analytics/statistics, leakage-safe ML, modality/lifecycle decisions, GenAI/RAG/tools/agents |
| Research and product | Source verification, fair comparisons, product evidence, prioritization, project dependencies, usable prototypes |
| Communication and artifacts | Writing/localization, Word/PDF/spreadsheets/slides, pitches and demos, learning/explanation |
| Quantitative and difficult decisions | Mathematics/scientific models, 31 thinking-method cards, 40 TRIZ principles, nine-stage deep contradiction analysis |
| Domain-sensitive work | Scope, authoritative evidence, and limits for consequential health/legal/financial/safety decisions |
| Competitions | Original five-stage sprint, scoring, strict validation, final delivery, and judge defense |

The domain-sensitive route does not confer professional qualifications. The deep TRIZ route is an original practical ARIZ adaptation, not a claim of formal certification or a copied contradiction matrix. Existing specialist skills and real project evidence determine implementation details.

## Package contents

```text
task-solver-suite/
├── README.md
├── SKILL.md
├── LICENSE
├── SOURCES.md
├── VALIDATION.md
├── references/              30 selectively loaded playbooks and method catalogs
├── templates/               7 optional working-document templates
├── scripts/
│   └── validate.py          Package and reference-graph checks
└── evaluations/
    ├── README.md            Evaluation design and limitations
    ├── cases.jsonl          Reproducible paired task fixtures
    ├── routing_cases.jsonl  Complex Russian-language routing exercises
    ├── run_comparison.py    Fresh read-only Codex runs
    └── score_results.py     Task checks, loading, usage, blind-review packets
```

The seven templates cover task contracts, decision records, research evidence, competition triage, experiment backlogs, pitch/demo scripts, and judge Q&A. They are intentionally blank working documents. Keep task outputs and private data separate from the installed suite. [SOURCES.md](SOURCES.md) records source provenance; [VALIDATION.md](VALIDATION.md) records measured checks and their limits.

## Installation

Copy the **whole `task-solver-suite` directory**, preserving its name and relative paths, into one skill directory supported by your agent. Do not copy only `SKILL.md`; its playbooks and templates are part of the package. Choose one scope per tool to avoid duplicate copies with diverging versions.

Paths below were checked against the linked official documentation on 2026-10-25. Project paths are relative to the project where you will use the skill; `~` means your user home directory.

| Agent | Project installation parent | Personal installation parent | Official instructions |
| --- | --- | --- | --- |
| Claude Code | `.claude/skills/` | `~/.claude/skills/` | [Claude Code skills](https://code.claude.com/docs/en/skills) |
| Cursor | `.cursor/skills/` | `~/.cursor/skills/` | [Cursor skills](https://cursor.com/help/customization/skills) |
| OpenCode | `.opencode/skills/` | `~/.config/opencode/skills/` | [OpenCode skills](https://docs.opencode.ai/docs/skills/) |
| Codex CLI | `.agents/skills/` | `~/.agents/skills/` | [Codex customization](https://learn.chatgpt.com/docs/customization/overview), [building skills](https://learn.chatgpt.com/docs/build-skills) |
| Gemini CLI | `.gemini/skills/` | `~/.gemini/skills/` | [Gemini CLI skills](https://geminicli.com/docs/cli/skills/) |
| Antigravity IDE | `.agents/skills/` | `~/.gemini/config/skills/` | [Antigravity skills](https://antigravity.google/docs/skills?app=antigravity-ide) |

Each destination ends in `task-solver-suite/SKILL.md`, for example `.claude/skills/task-solver-suite/SKILL.md`. Some tools also discover shared `.agents/skills` locations; use the tool-specific path above unless you deliberately want a shared installation. Skill discovery and UI commands depend on the installed client version. Reopen the project/session or use its documented refresh mechanism after copying.

### macOS / Linux example

Run from the project where the skill should be installed. Set the source to the existing package directory and choose the installation parent from the table. This example installs for Claude Code and stops if a copy already exists.

```bash
suite_source="/absolute/path/to/task-solver-suite"
install_parent=".claude/skills"
destination="$install_parent/task-solver-suite"
if [ ! -f "$suite_source/SKILL.md" ]; then
  printf '%s\n' "Source SKILL.md not found."
elif [ -e "$destination" ]; then
  printf '%s\n' "Destination already exists; review that copy before updating."
else
  mkdir -p "$install_parent"
  cp -R "$suite_source" "$destination"
fi
```

Use `.cursor/skills` for Cursor, `.opencode/skills` for OpenCode, or `.agents/skills` for Codex CLI. For a personal installation, use the corresponding absolute home path, such as `install_parent="$HOME/.agents/skills"`.

### Windows PowerShell example

Run from the target project. The example installs for Codex CLI; change `$installParent` using the table for another agent.

```powershell
$suiteSource = 'C:\path\to\task-solver-suite'
$installParent = '.agents\skills'
$destination = Join-Path $installParent 'task-solver-suite'
if (-not (Test-Path -LiteralPath (Join-Path $suiteSource 'SKILL.md'))) {
    throw 'Source SKILL.md not found.'
}
if (Test-Path -LiteralPath $destination) {
    throw 'Destination already exists; review that copy before updating.'
}
New-Item -ItemType Directory -Path $installParent -Force | Out-Null
Copy-Item -LiteralPath $suiteSource -Destination $destination -Recurse
```

For personal Codex use, set `$installParent = Join-Path $HOME '.agents\skills'`. These examples copy files only; they do not install or configure the agent application itself.

### Confirm discovery and invoke

- **Claude Code:** Use `/task-solver-suite`, followed by the task. The description also supports relevant automatic discovery.
- **Codex CLI:** Select the skill in `/skills` or mention `$task-solver-suite` with the task.
- **Cursor, OpenCode, Gemini CLI, Antigravity:** Ask the agent to use the `task-solver-suite` skill, then verify it has loaded the root instructions and the relevant local playbook. Use the client's skill controls if available; there is no universal slash command across these clients.

If the client does not support Agent Skills or discovery fails, explicitly provide the local `SKILL.md` path and ask the agent to read it, then follow its relevant relative links. This manual fallback supplies instructions but does not add automatic discovery. Check client version and path before adding wrappers or changing frontmatter.

## Usage examples

**Existing code:** “Use task-solver-suite to add this behavior to the current application. Inspect the call sites, keep the existing architecture, and verify the changed contract.”

**Data analysis:** “Use task-solver-suite to investigate why revenue doubled after this join. Here are the tables and query. Fix the aggregation and show a hand-checkable example.”

**Research:** “Use task-solver-suite to compare these approaches under our latency, deployment, and license constraints. Use primary evidence and distinguish measured results from vendor claims.”

**Mixed delivery:** “Use task-solver-suite to analyze the dataset and produce a decision memo with an editable spreadsheet. Load the analysis and artifact workflows when each deliverable needs them.”

**Kickoff:** “Use task-solver-suite for this 24-hour hackathon. Here are the rules and rubric. We have two people and a fixed API budget. Produce the minimum scope, acceptance criteria, cut list, and schedule.”

**Predictive ML:** “Use task-solver-suite to design validation for patient-level predictions from repeated scans. Labels arrive later than acquisition. Review feature availability, propose the split, and prepare an experiment backlog before training.”

**GenAI product:** “Use task-solver-suite to build a cited assistant over these permitted documents. A useful answer must arrive within our measured latency and cost budgets. Choose the simplest architecture and define success, abstention, and outage tests.”

**Trade-off:** “Use task-solver-suite to resolve a validation-quality gain that doubles inference time beyond the event limit. Compare separation options and define the cheapest useful experiment.”

**Pitch only:** “Use task-solver-suite to turn these measured results and working demo into a three-minute pitch and judge Q&A. Keep the existing build and mark unsupported claims.”

Supply the actual brief/rules, deadline/timezone, available work, measurements, resources, and requested deliverables where known. The agent should ask only about decision-changing gaps and continue work supported by the available evidence.

## Validation and maintenance

The package follows the [Agent Skills specification](https://agentskills.io/specification), with a matching folder/name, YAML frontmatter, progressive disclosure, and local reference paths. The suite's root must stay below 6,000 tokens; token counts vary by tokenizer, so the validation report names the encodings used.

The skill instructions have no external dependencies. The included structural validator uses Python's standard library; the paired runtime evaluation also requires an authenticated Codex CLI and consumes model usage. From this package directory:

```text
python scripts/validate.py --self-test
python scripts/validate.py
```

It checks local Markdown link boundaries, reference reachability, expected module paths in evaluation fixtures, UTF-8, and the package's simple metadata markers. It is not a general YAML parser or tokenizer. Optional development lint uses upstream skillmd. From the directory containing this package, with Node.js/npm available:

```bash
npx --yes --package skillmds@1.3.3 skillmd lint ./task-solver-suite --strict --format json
```

This downloads a pinned linter package if it is not cached; it is not an installation requirement. The [paired evaluation guide](evaluations/README.md) explains baseline/treatment controls, artifact scoring, read traces, token usage, and limitations. Run model-based evaluation only within authorized usage. See [VALIDATION.md](VALIDATION.md) for actual results, source/installation checks, and remaining client-dependent verification. A lint score does not establish task effectiveness.

After edits, recheck frontmatter, local links/reachability, size, and realistic requests for changed routes, including a nearby task that should not load them. Keep prompts and scoring fixed before comparative runs, retain failures, and report quality alongside context/time costs. Maintain one authoritative copy of each rule: routing in `SKILL.md`, domain detail in references, output fields in templates.

## Sources and license

This is an original synthesis informed by [SOURCES.md](SOURCES.md) and the primary references linked in each playbook. Version 2 adds 31 verified method identities with original task procedures, all 40 TRIZ principle prompts, and deeper contradiction analysis. It does not reproduce every upstream framework or dependency. Unverified upstream counts and ambiguous source identity remain documented.

New material is licensed under [MIT](LICENSE). Linked upstream projects keep their own licenses. No upstream code or skills are vendored. There is no implied endorsement by the named platforms or source maintainers.
