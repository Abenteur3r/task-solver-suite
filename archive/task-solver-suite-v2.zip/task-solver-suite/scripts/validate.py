#!/usr/bin/env python3
"""Check package structure and local links; YAML lint/tokenization are separate."""
import argparse
import json
import pathlib
import re
import tempfile
import unittest
from urllib.parse import unquote, urlsplit


def prose_lines(text):
    """Ignore fenced code so example links are not treated as package links."""
    fence = None
    for line in text.splitlines():
        match = re.match(r"^\s*(`{3,}|~{3,})(.*)$", line)
        if match:
            marker = match[1]
            if fence is None:
                fence = marker
            elif marker[0] == fence[0] and len(marker) >= len(fence) and not match[2].strip():
                fence = None
            continue
        if fence is None:
            yield line


def inspect(root):
    root = pathlib.Path(root).resolve()
    errors, edges, links = [], {}, 0
    for name in ("SKILL.md", "README.md", "LICENSE"):
        if not (root / name).is_file():
            errors.append(f"Missing {name}")
    skill = root / "SKILL.md"
    raw = skill.read_text(encoding="utf-8") if skill.is_file() else ""
    match = re.match(r"\A---\r?\n(.*?)\r?\n---(?:\r?\n|$)", raw, re.S)
    if not match:
        errors.append("SKILL.md needs fenced frontmatter with no byte-order mark")
    else:
        # Deliberately inspect only this package's plain one-line name field.
        # This is not a YAML parser; use the official SkillMD engine for YAML.
        names = re.findall(r"^name:\s*([a-z0-9-]+)\s*$", match[1], re.M)
        if len(names) != 1 or names[0] != root.name:
            errors.append("Exactly one plain name field must match the skill directory")
        elif len(names[0]) > 64 or not re.fullmatch(r"[a-z0-9]+(?:-[a-z0-9]+)*", names[0]):
            errors.append("Skill name violates the open-standard name constraint")
        for field in ("description", "license"):
            if not re.search(rf"^{field}:\s*\S", match[1], re.M):
                errors.append(f"Missing nonempty {field} field")
    documents = sorted(root.rglob("*.md"))
    for doc in documents:
        if not doc.resolve().is_relative_to(root):
            errors.append(f"Document escapes package: {doc}")
            continue
        try:
            content = doc.read_text(encoding="utf-8")
        except UnicodeError:
            errors.append(f"Invalid UTF-8: {doc.relative_to(root)}")
            continue
        if "\ufffd" in content:
            errors.append(f"Replacement character: {doc.relative_to(root)}")
        edges[doc.resolve()] = set()
        for line in prose_lines(content):
            for match in re.finditer(r"\[[^\]]+\]\((<[^>]+>|[^\s)]+)(?:\s+\"[^\"]*\")?\)", line):
                target = unquote(match[1].strip("<>"))
                if target.startswith("#"):
                    continue
                if pathlib.PureWindowsPath(target).drive or target.startswith(("/", "\\")):
                    errors.append(f"Absolute local link in {doc.relative_to(root)}: {target}")
                    continue
                if urlsplit(target).scheme:
                    continue
                local = target.split("#", 1)[0].split("?", 1)[0]
                if not local:
                    continue
                resolved = (doc.parent / local).resolve()
                links += 1
                if not resolved.is_relative_to(root):
                    errors.append(f"Escaping link in {doc.relative_to(root)}: {target}")
                elif not resolved.exists():
                    errors.append(f"Broken link in {doc.relative_to(root)}: {target}")
                else:
                    edges[doc.resolve()].add(resolved)
    reached, todo = set(), [skill.resolve()]
    while todo:
        item = todo.pop()
        if item in reached:
            continue
        reached.add(item)
        for child in edges.get(item, ()):
            relative = child.relative_to(root)
            if relative.parts[0] in ("references", "templates"):
                todo.append(child)
    resources = [p.resolve() for folder in ("references", "templates") for p in (root / folder).rglob("*.md")]
    for resource in resources:
        if resource not in reached:
            errors.append(f"Unreachable from SKILL.md: {resource.relative_to(root)}")
    evaluation_cases, evaluation_paths = 0, 0
    package_files = {p.relative_to(root).as_posix() for p in root.rglob("*") if p.is_file()}
    for fixture in sorted((root / "evaluations").glob("*.jsonl")):
        try:
            lines = fixture.read_text(encoding="utf-8").splitlines()
        except UnicodeError:
            errors.append(f"Invalid UTF-8: {fixture.relative_to(root)}")
            continue
        for number, line in enumerate(lines, 1):
            if not line.strip():
                continue
            location = f"{fixture.relative_to(root)}:{number}"
            try:
                case = json.loads(line)
            except ValueError:
                errors.append(f"Invalid JSON at {location}")
                continue
            evaluation_cases += 1
            paths = case.get("allowed_references") if isinstance(case, dict) else None
            if not isinstance(paths, list):
                errors.append(f"Expected allowed_references list at {location}")
                continue
            for path in paths:
                evaluation_paths += 1
                if (not isinstance(path, str) or path not in package_files
                        or not (root / path).resolve().is_relative_to(root)):
                    errors.append(f"Missing, escaping, or nonexact evaluation reference at {location}: {path}")
    return {
        "ok": not errors, "errors": errors, "markdown_files": len(documents),
        "local_links": links, "reachable_resources": len(set(resources) & reached),
        "root_bytes": len(raw.encode("utf-8")), "root_lines": len(raw.splitlines()),
        "evaluation_cases": evaluation_cases, "evaluation_reference_paths": evaluation_paths,
        "token_count": None,
        "limits": "Inline Markdown links and JSONL allowed_references paths only; anchors and remote URLs are not checked. YAML and exact token counts require separate tools.",
    }


class ValidatorChecks(unittest.TestCase):
    def fixture(self, extra=""):
        temp = tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        root = pathlib.Path(temp.name) / "sample"
        root.mkdir()
        (root / "SKILL.md").write_text("---\nname: sample\ndescription: A sample skill for testing.\nlicense: MIT\n---\n# Skill\n" + extra, encoding="utf-8")
        (root / "README.md").write_text("# Readme\n", encoding="utf-8")
        (root / "LICENSE").write_text("MIT\n", encoding="utf-8")
        return root

    def test_valid_and_code_example(self):
        self.assertTrue(inspect(self.fixture("```md\n[example](absent.md)\n```\n"))["ok"])

    def test_broken_and_encoded_escape(self):
        result = inspect(self.fixture("[missing](absent.md)\n[escape](%2e%2e/out.md)\n[drive](C:outside.md)\n"))
        self.assertEqual(len(result["errors"]), 3)

    def test_unreachable_then_linked(self):
        root = self.fixture()
        (root / "references").mkdir()
        (root / "references" / "one.md").write_text("# One\n", encoding="utf-8")
        self.assertFalse(inspect(root)["ok"])
        with (root / "SKILL.md").open("a", encoding="utf-8") as stream:
            stream.write("[one](references/one.md)\n")
        self.assertTrue(inspect(root)["ok"])

    def test_duplicate_name(self):
        root = self.fixture()
        p = root / "SKILL.md"
        p.write_text(p.read_text().replace("name: sample", "name: sample\nname: other"), encoding="utf-8")
        self.assertFalse(inspect(root)["ok"])

    def test_fixture_reference_must_exist_with_exact_path(self):
        root = self.fixture()
        (root / "evaluations").mkdir()
        fixture = root / "evaluations" / "cases.jsonl"
        fixture.write_text(json.dumps({"allowed_references": ["references/one.md"]}) + "\n", encoding="utf-8")
        self.assertTrue(any("evaluation reference" in error for error in inspect(root)["errors"]))
        (root / "references").mkdir()
        (root / "references" / "one.md").write_text("# One\n", encoding="utf-8")
        with (root / "SKILL.md").open("a", encoding="utf-8") as stream:
            stream.write("[one](references/one.md)\n")
        self.assertTrue(inspect(root)["ok"])
        fixture.write_text(json.dumps({"allowed_references": ["references/One.md"]}) + "\n", encoding="utf-8")
        self.assertTrue(any("evaluation reference" in error for error in inspect(root)["errors"]))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("path", nargs="?", default=str(pathlib.Path(__file__).resolve().parents[1]))
    parser.add_argument("--self-test", action="store_true")
    args = parser.parse_args()
    if args.self_test:
        unittest.main(argv=[__file__])
    else:
        result = inspect(args.path)
        print(json.dumps(result, indent=2))
        raise SystemExit(0 if result["ok"] else 1)
